<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Productos</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
</head>
<body>
    <main>
    <div class="contenedor__productos">
                  <form action="producto.php" method="POST" class="formulario__register">
                  <!--asegurarse que el archivo se llame así-->
                      <h2>Productos</h2>
                      <input type="text" placeholder="Código" name="codigo_producto">
                      <input type="text" placeholder="Descripción" name="descripcion">
                      <input type="float" placeholder="Precio" name="precio">
                      <button>Cargar Producto</button>
                  </form>
         </div>
        </main>
        <script> </script>
     </body>
</html>