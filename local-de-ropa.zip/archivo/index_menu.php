<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Menu de Navegación</title>
  <link rel="stylesheet" >
</head>
<body>

  <header>
    <div class="menu">
     
      <nav>
          <ul>
           <li><a href="http://localhost/login-register/index_producto.php">Cargar producto</a></li>  
           <li><a href="http://localhost/login-register/index_pedido.php">Cargar pedido</a></li>
           <li><a href="http://localhost/login-register/index_cons.php">Ver pedido</a></li>
          </ul>
      </nav>
    </div>
  </header>

</body>
<h2> Hola,¡Bienvenido!</h2>
</html>